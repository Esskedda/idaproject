const templateCard = (imgSrc, title, text, price) => `
 
        <div class="photos" style="background-image: url('${imgSrc}'); max-width: 100%; height: 200px; background-repeat: no-repeat; background-size: cover; border-radius: 4px 4px 0 0;"></div>
        <div class="text">
								<span>${title}</span>
							<p>
                            ${text}
                            </p>
    <strong>${price} руб.</strong>
    </div>
    <a href="#" class="delete"><img src="img/delete.svg" alt=""></a>
`;



let imginput = document.querySelector('.img-input');
let btncard = document.querySelector('.btn-card');
let wrapper = document.querySelector('.myclass');
let price = document.querySelector('.price');
let textarea = document.querySelector('.textarea');
let title = document.querySelector('.title');
btncard.addEventListener('click', function(){


    const htmlCard = templateCard(imginput.value, title.value, textarea.value, price.value)
    const $newCard = document.createElement('div');

    $newCard.className = 'card';
    $newCard.innerHTML = htmlCard;

    wrapper.appendChild($newCard)

})


function remove(){
  let w = this.closest('.card'), br = w.nextElementSibling;
  
  if(br.nodeType === 1 && br.nodeName === 'BR')
    br.remove();
  
  w.remove();
}

Array.from(document.querySelectorAll('.delete')).forEach(b => b.addEventListener('click', remove));